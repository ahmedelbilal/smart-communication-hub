export type Insight = {
  id: string;
  summary: string;
};
