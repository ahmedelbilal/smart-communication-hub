export const EXTERNAL_API_BASE = process.env.EXTERNAL_API_BASE || 'http://localhost:3000/api';
export const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL || 'http://localhost:3000';
